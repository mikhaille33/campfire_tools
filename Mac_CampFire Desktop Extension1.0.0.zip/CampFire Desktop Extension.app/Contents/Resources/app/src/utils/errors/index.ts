export class HttpError extends Error {
  status: number;
  constructor(message: string, status?: number) {
    super(message || "Oops, something went wrong. Please try again later.");

    this.status = status || 500;
  }
}
