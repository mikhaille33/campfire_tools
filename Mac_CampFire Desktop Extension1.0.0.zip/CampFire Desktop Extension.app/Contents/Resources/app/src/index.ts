import {
  app,
  BrowserWindow,
  Menu,
  Tray,
  shell,
  MenuItem,
  MenuItemConstructorOptions,
} from "electron";
import * as path from "path";

// Media server imports
import { createMediaServer, closeMediaServer } from "./servers/mediaServer";

// Torrent search server imports
import {
  createTsServer,
  closeTsServer,
} from "./servers/torrentSearchServer/tsServer";

let serverRunning: boolean = false;
let tray: Tray;

// Handle creating/removing shortcuts on Windows when installing/uninstalling.
if (require("electron-squirrel-startup")) {
  // eslint-disable-line global-require
  app.quit();
}
let TrayCreated: boolean = false;
const createTray = () => {
  if (TrayCreated) return;
  let contextMenu;
  tray = new Tray(path.join(__dirname, "../src/assets/favicon_16x16.png"));

  const buildTrayMenu = () => {
    // Create a new tray and replace any previous tray with it
    contextMenu = Menu.buildFromTemplate(template);
    tray.setContextMenu(contextMenu);
    TrayCreated = true;
  };

  let template: (MenuItemConstructorOptions | MenuItem)[] = [
    // The buttons that will show up when the tray icon is clicked on
    {
      label: serverRunning
        ? "Media server is ONLINE 🟢"
        : "Media server is OFFLINE 🔴",
      type: "normal",
    },
    {
      label: "Open CampFire",
      type: "normal",
      click: () => {
        shell.openExternal("https://campfire.now.sh");
      },
    },
    {
      label: serverRunning ? "Close server" : "Start server",
      type: "normal",
      click: () => {
        // Close/open the servers and change the tray accordingly
        if (serverRunning) {
          closeMediaServer();
          closeTsServer();
        } else {
          createMediaServer();
          createTsServer();
        }

        serverRunning = !serverRunning;
        template[0].label = serverRunning
          ? "🟢 Torrent server is ONLINE"
          : "🔴 Torrent server is OFFLINE";
        template[2].label = serverRunning ? "Close server" : "Start server";
        buildTrayMenu();
      },
    },
    {
      label: "Quit",
      type: "normal",
      click: () => {
        app.quit();
      },
    },
  ];
  buildTrayMenu();
};

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
// app.on("ready", () => {
//   // app.dock.hide();
//   createMediaServer();
//   createTsServer();
//   serverRunning = true;
//   createTray();
// });

// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

app.on("activate", () => {
  // On OS X it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  if (BrowserWindow.getAllWindows().length === 0) {
    // createWindow();
  }
});

if (process.defaultApp) {
  if (process.argv.length >= 2) {
    app.setAsDefaultProtocolClient("campfire-dx", process.execPath, [
      path.resolve(process.argv[1]),
    ]);
  }
} else {
  app.setAsDefaultProtocolClient("campfire-dx");
}

// Deep linked url
let deeplinkingUrl: any;

//For mac
app.on("open-url", function (event, url) {
  event.preventDefault();
  deeplinkingUrl = url;
});

// Force Single Instance Application
const gotTheLock = app.requestSingleInstanceLock();

if (!gotTheLock) {
  app.quit();
} else {
  app.on("second-instance", (e, argv) => {
    // Someone tried to run a second instance, we should focus our window.
    // Protocol handler for win32
    // argv: An array of the second instance’s (command line / deep linked) arguments
    if (process.platform == "win32") {
      // Keep only command line / deep linked arguments
      deeplinkingUrl = argv.slice(1);
    }
  });

  // Create mainWindow, load the rest of the app, etc...
  // app.whenReady().then(() => {
  //   // app.dock.hide();
  //   createMediaServer();
  //   createTsServer();
  //   serverRunning = true;
  //   createTray();
  // });

  app.on("ready", () => {
    app.dock?.hide();
    if (TrayCreated) return;
    if (!createMediaServer()) return false;
    createTsServer();
    serverRunning = true;
    createTray();
  });
}

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and import them here.
