import express, { Request, Response, NextFunction, Express } from "express";
import helmet from "helmet";
import cors from "cors";
import bodyParser from "body-parser";
import { createHttpTerminator, HttpTerminator } from "http-terminator";
// import { Server } from "http";
import WebTorrent, { Torrent } from "webtorrent";
import tsApi from "torrent-search-api";
import { Error } from "../@types";
import { HttpError } from "../utils/errors";

interface TorrentWrapper {
  magnetLink?: string | null;
  instance?: Torrent | null;
  server?: any;
  medias?: any; //[{ idx: number; name: string }];
  subtitlesIndices?: any;
  err?: HttpError | null;
  port?: number;
}
let httpTerminator: HttpTerminator;
let client: WebTorrent.Instance;
let server;
let torrentWrapper: TorrentWrapper = {};
let initial_port = 12283;
// let torrentPort_A: number = 12283;
// let torrentPort_B: number = 12284;
// let prev_torrentPort: number = 12284;

const wait = (x: number) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(true);
    }, x * 1000);
  });
};

const watch = (torrent: any) => {
  return new Promise(async (resolve) => {
    while (1) {
      console.log("checking torrent wrapper");
      if (
        torrent &&
        torrentWrapper.medias &&
        torrentWrapper.subtitlesIndices &&
        torrentWrapper.port
      ) {
        break;
      }
      await wait(2);
    }
    resolve(true);
  });
};

export const createMediaServer = (): boolean => {
  server = express();
  server.use(helmet());
  // server.use(cors({ origin: "https://campfire.now.sh" }));
  server.use(cors());
  server.use(bodyParser.json());

  client = new WebTorrent();

  // Each torrent's files will be served on a different port
  server.get(
    "/streamTorrent",
    async (req: Request, res: Response, next: NextFunction) => {
      try {
        if (!req.query.magnetLink) {
          const err = new HttpError("Magnet link must be specified.");
          err.status = 400;
          console.log("Magnet link must be specified.");
          return next(err);
        }
        const magnetLink = req.query.magnetLink as string;

        //when new magentlink is same as old one by accident, ignore it.
        if (torrentWrapper.magnetLink === magnetLink) {
          //wait 15 seconds until the  torrent is created successfully, it is just for local test, will be not used in the real life, actually.
          await watch(torrentWrapper);
          return res.status(200).send({
            medias: torrentWrapper.medias,
            subtitlesIndices: torrentWrapper.subtitlesIndices,
            port: torrentWrapper.port,
          });
        }
        torrentWrapper.magnetLink = magnetLink;
        // Create an object that will contain all the torrent's details

        client.add(magnetLink, async (torrent: Torrent) => {
          console.log("torrent-path", torrent.path);
          torrentWrapper.instance = torrent;
          // Create an HTTP server for this torrent for the web client to stream from
          // Create a server key and point it to a torrent server
          torrentWrapper.server = torrent.createServer();
          //Decide which port to use based on the previous port, should not select the previous port at least.
          torrentWrapper.port = initial_port;
          // torrentWrapper.port =
          //   prev_torrentPort === torrentPort_A ? torrentPort_B : torrentPort_A;
          // prev_torrentPort = torrentWrapper.port;
          initial_port++;
          // Initialize the server
          console.log("current port:", torrentWrapper.port);
          torrentWrapper.server.listen(torrentWrapper.port, () => {
            // Get the indices for the media file and the index for the subtitles file if it exists
            let medias: any = [];
            let subtitlesIndices: any = [];
            torrent.files.forEach((file, index) => {
              if (file.name.endsWith(".mp4") || file.name.endsWith(".mkv")) {
                medias.push({
                  name: file.name,
                  index,
                });
              }
              // Check if the torrent comes with subtitles
              if (file.name.endsWith(".srt"))
                subtitlesIndices.push({ name: file.name, index });
            });
            if (!medias.length) {
              // No mp4 or mkv file. Stop downloading the torrent and return an error
              client.remove(magnetLink);

              const err = new HttpError(
                "No compatible files found. Please select a different source, or a different title."
              );
              err.status = 404;

              // If the user tries to add this torrent again, let them know why it failed
              torrentWrapper.err = err;
              console.log(
                "No compatible files found. Please select a different source, or a different title."
              );
              return next(err);
            }

            // Assign all information to keys in the torrent's object
            torrentWrapper.magnetLink = magnetLink;
            torrentWrapper.medias = medias;
            torrentWrapper.subtitlesIndices = subtitlesIndices;
            // Let the browser know which indices to append to the URL when trying to get the media/subtitle files, and on which port to find them
            return res.send({
              medias: medias,
              subtitlesIndices: subtitlesIndices,
              port: torrentWrapper.port,
            });
          });
        });
        client.on("error", (e) => {
          console.log("Invalid torrent identifier", e);
          const err = new HttpError("Invalid torrent identifier");
          //@TODO: still error: Cannot set headers after they are sent to the client
          return next(err);
        });
      } catch (err) {
        console.log("streamTorrent", err);
        next(err);
      }
    }
  );

  server.post(
    "/toMagnet",
    async (req: Request, res: Response, next: NextFunction) => {
      // Convert a tsApi torrent object to a magnet link. Done here and not on the server to decrease server load and make it faster for users.
      // In the future all torrent operations will be done on the desktop extension.
      try {
        const magnet = await tsApi.getMagnet(req.body);
        res.status(200).send(magnet);
      } catch (err) {
        console.log("/toMagnet error:", err);
        next(err);
      }
    }
  );

  server.post(
    "/removeTorrent",
    (req: Request, res: Response, next: NextFunction) => {
      console.log("remove torrent and close server");
      if (!torrentWrapper.server) {
        torrentWrapper = {};
        return res.status(200).send("Torrent server closed.");
      }
      torrentWrapper.server?.close(() => {
        // torrentPort++;
        torrentWrapper = {};
        return res.status(200).send("Torrent server closed.");
      });
      // This is same thing: client.remove(torrentWrapper.magnetLink, { destroyStore: true }); == torrentWrapper.instance.destroy({ destroyStore: true });
      //@TODO: don't forget to set destroyStore as true when in production
      torrentWrapper.instance.destroy({ destroyStore: true });
      // torrentWrapper.instance?.destroy();
    }
  );

  server.get("/restartServer", async (req, res) => {
    await closeMediaServer();
    createMediaServer();
    res.status(200).send("Server restarted.");
  });

  server.use((err: Error, req: Request, res: Response, next: NextFunction) => {
    res.status(err.status || 500).send(err.message || "Internal error.");
  });

  server = server.listen(7800);
  server.on("error", (err) => {
    console.log("7800: error", err);
    return false;
  });

  httpTerminator = createHttpTerminator({
    server,
    gracefulTerminationTimeout: 0,
  });
  return true;
};

export const closeMediaServer = async () => {
  torrentWrapper.server?.close();
  torrentWrapper.instance?.destroy({ destroyStore: true });
  torrentWrapper = {};
  // Close the express server so users cant ask for any new torrent servers to be opened
  if (client) client.destroy();
  if (httpTerminator) await httpTerminator.terminate();
};
