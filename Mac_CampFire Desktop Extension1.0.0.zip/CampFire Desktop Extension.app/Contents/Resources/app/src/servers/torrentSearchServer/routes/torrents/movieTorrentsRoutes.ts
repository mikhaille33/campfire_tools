import express from "express";
import { movieTorrentsController } from "../../controllers/torrents";

const router = express.Router();

router.get("/", movieTorrentsController.getMovieTorrents);

export default router;
