import express from "express";
import { tvTorrentsController } from "../../controllers/torrents";

const router = express.Router();
router.get("/", tvTorrentsController.getShowTorrents);

export default router;
