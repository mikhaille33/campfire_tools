const TorrentSearchApi = require("torrent-search-api");
// tsApi object with some custom configuration for global usage.
// All future configuration should go in here.

TorrentSearchApi.enablePublicProviders();
TorrentSearchApi.disableProvider("Torrent9");
TorrentSearchApi.disableProvider("KickassTorrents");

export { TorrentSearchApi };
