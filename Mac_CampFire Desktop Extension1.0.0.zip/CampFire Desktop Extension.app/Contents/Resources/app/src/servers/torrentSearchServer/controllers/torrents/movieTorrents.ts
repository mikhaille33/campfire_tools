import { Request, Response, NextFunction } from "express";
import { HttpError } from "../../../../utils/errors/index";
import { TorrentSearchApi as tsApi } from "../../utils/torrentSearchApi";

export const getMovieTorrents = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // For a given movie title (i.e: "Star Wars"), get a list of torrents
  try {
    const torrents = await tsApi.search(req.query.title, "Movies", 10);
    return res.send(torrents);
  } catch (err) {
    // TODO: Handle different error cases, i.e: user sends a request without a title.
    next(
      new HttpError(
        "Failed to fetch torrents. Our torrent sources may be currently unavailable."
      )
    );
  }
};
