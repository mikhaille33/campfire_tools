import hsbApi from "horriblesubs-node";
import { Request, Response, NextFunction } from "express";
import { HttpError } from "../../../../utils/errors/index";

export const getEpisodes = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // For a given anime's title, get episode (paginated) torrents, divided by the episode's available resolutions (480p, 1080p, etc)
  try {
    // Extract the title and convert it to hsb-node's expected format

    const title = (<string>req.query.title).replace(" ", "-");
    const page = req.query.page as unknown as number;

    const torrents = gaEpisodes(title, page);
    return res.send(torrents);
  } catch (err) {
    next(new HttpError(err));
  }
};

export const getEpisode = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // For a given anime title and episode, get torrents for the episode
  try {
    const title = (<string>req.query.title).replace(" ", "-");
    const desEpNum = req.query.epNum as unknown as number;

    // hsb-node doesn't support getting torrents for a specific episode.
    // Have to access torrents for the entire show, calculate on which page the episode's torrents will be,
    // and then grab it from that page.
    // Since each page has 11 results, and the first page is page 0, this information can be calculated like this:
    // floor( ({ the show's latest episode } - { the desired episode} / 11) - 1 )

    // Calculate latest ep num
    const eps = await gaEpisodes(title, 0);
    const latestEp = eps[0].epNum;

    // Calculate the desired episode's page number
    const desEpPageNum = Math.floor((latestEp - desEpNum) / 11 - 1);

    // Get that page
    const desEpPage = await gaEpisodes(title, desEpPageNum);

    // Extract the desired ep's torrents (get the entire ep object first, then extract the torrents out of it)
    let desEpTorrents = desEpPage.find((episode) => episode.epNum == desEpNum);

    return res.send(desEpTorrents.resolutions);
  } catch (err) {
    next(new HttpError(err.message));
  }
};

const gaEpisodes = async (title: string, page: number) => {
  const res: hsbApi.Episode[] = await hsbApi.getEpisodes(
    { slug: title },
    { page: page }
  );

  const torrents = res.map((episode) => {
    // Extract relevant data
    return {
      epNum: episode.chapter.episode,
      resolutions: episode.resolutions,
    };
  });
  return torrents;
};
