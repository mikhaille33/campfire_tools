export * as animeTorrentsController from "./animeTorrents";
export * as movieTorrentsController from "./movieTorrents";
export * as tvTorrentsController from "./tvTorrents";
