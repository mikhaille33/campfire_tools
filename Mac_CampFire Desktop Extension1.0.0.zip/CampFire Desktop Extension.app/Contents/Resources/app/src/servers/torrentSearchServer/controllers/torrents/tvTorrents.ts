import { Request, Response, NextFunction } from "express";
import { HttpError } from "../../../../utils/errors/index";
import { TorrentSearchApi as tsApi } from "../../utils/torrentSearchApi";

export const getShowTorrents = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // For a given tv show's season and episode (i.e: Breaking Bad, season 1, episode 5) get a list of torrents
  try {
    const title = req.query.title;
    const req_season = req.query.season as unknown as number;
    const req_ep = req.query.episode as unknown as number;

    // File naming convention: episode and season names below 10 are number as 0x (i.e: 01, 02, etc)
    const season = req_season > 9 ? req_season : `0${req_season}`;
    const episode = req_ep > 9 ? req_ep : `0${req_ep}`;

    // The query to send to the torrent providers, using the following naming convention shown in the code,
    // which ends up looking like "Breaking Bad s03e10"
    const query = `${title} s${season}e${episode}`;

    const torrents = await tsApi.search(query, "TV", 10);

    return res.send(torrents);
  } catch (err) {
    // TODO: Handle different error cases, i.e: user sends a request without a title.
    next(
      new HttpError(
        "Failed to fetch torrents. Our torrent sources may be currently unavailable."
      )
    );
  }
};
