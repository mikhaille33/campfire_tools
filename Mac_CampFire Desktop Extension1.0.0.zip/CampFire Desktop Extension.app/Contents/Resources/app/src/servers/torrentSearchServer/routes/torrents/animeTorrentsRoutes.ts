import express from "express";
import { animeTorrentsController } from "../../controllers/torrents";

const router = express.Router();
router.get("/", animeTorrentsController.getEpisode);
router.get("/getEpisodes", animeTorrentsController.getEpisodes);

export default router;
