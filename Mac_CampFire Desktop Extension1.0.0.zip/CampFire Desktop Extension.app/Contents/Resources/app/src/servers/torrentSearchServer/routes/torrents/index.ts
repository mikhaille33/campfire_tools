import express from "express";

import movieRoutes from "./movieTorrentsRoutes";
import tvRoutes from "./tvTorrentsRoutes";
import animeRoutes from "./animeTorrentsRoutes";

const router = express.Router();
router.use("/movies", movieRoutes);
router.use("/tv", tvRoutes);
router.use("/anime", animeRoutes);

export default router;
