import express, { Request, Response, NextFunction } from "express";
import helmet from "helmet";
import bodyParser from "body-parser";
import cors from "cors";
import { createHttpTerminator, HttpTerminator } from "http-terminator";
import { Error } from "../../@types";

// Route imports
import torrentRoutes from "./routes/torrents";

let httpTerminator: HttpTerminator;

export const createTsServer = () => {
  const app = express();
  app.use(helmet());
  app.use(cors());
  app.use(bodyParser.json());

  // Routes setup
  app.use("/torrents", torrentRoutes);

  //Ping route
  app.get("/ping", (req: Request, res: Response, next: NextFunction) => {
    res.status(200).send("OK");
  });

  // Error handling
  app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
    const { message, status } = err;
    res.status(status).json({
      status,
      message,
    });
    res.send();
  });

  const server = app.listen(5000);
  httpTerminator = createHttpTerminator({
    server,
    gracefulTerminationTimeout: 0,
  });
};

export const closeTsServer = async () => {
  if (httpTerminator) await httpTerminator.terminate();
};
